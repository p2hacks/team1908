import UIKit


class accountManager {
    
    var accounts: [account] = []
    
    func decode(){
        
        func getJSONData() throws -> Data? { //ファイルからデータを取り出す
            

            let thePath = NSHomeDirectory()+"/Documents/\(ID).json"
            let theURL = URL(fileURLWithPath: thePath)
            
            return try Data(contentsOf: theURL)
        }
        
        guard let data = try? getJSONData() else { return }
        guard let profiles = try? JSONDecoder().decode(Profile.self, from: data!) else { return }
        
    }
    
    func encode(){
        
        let record = Record( name: Name, profile: Profile, ID: id, intimacy: Intimacy)
        
        let encoder = JSONEncoder()
        
        do {
            let data = try encoder.encode(record)
            let jsonstr:String = String(data: data, encoding: .utf8)!
            print(jsonstr)
            
        } catch {
            print(error.localizedDescription)
        }
        
        //
        func saveEntriesToJson(filePath:String, ID:String) {
            let jsonPath = filePath + "/\(ID)"
            
            let jsonEncoder = JSONEncoder()
            jsonEncoder.outputFormatting = .prettyPrinted
            
            let data = try! jsonEncoder.encode(entries)
            let dataStr = String(data:data,encoding:.utf8)
            
            if dataStr?.isEmpty ?? true { return }
            do {
                // Stringデータをファイルに書き出し
                try dataStr!.write(toFile: jsonPath, atomically: true, encoding: .utf8)
            } catch _ {
                print("Write Error!  File : \(jsonPath)")
            }
        }
        
    }
    
}
